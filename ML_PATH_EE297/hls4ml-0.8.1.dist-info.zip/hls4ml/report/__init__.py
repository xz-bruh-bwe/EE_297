from hls4ml.report.quartus_report import parse_quartus_report  # noqa: F401
from hls4ml.report.quartus_report import read_quartus_report  # noqa: F401
from hls4ml.report.vivado_report import parse_vivado_report  # noqa: F401
from hls4ml.report.vivado_report import print_vivado_report  # noqa: F401
from hls4ml.report.vivado_report import read_vivado_report  # noqa: F401
