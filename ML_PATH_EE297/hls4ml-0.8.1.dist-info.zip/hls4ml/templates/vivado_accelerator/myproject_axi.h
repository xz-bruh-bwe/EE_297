#ifndef MYPROJECT_AXI_H_
#define MYPROJECT_AXI_H_

#include <iostream>
// hls-fpga-machine-learning insert include

// hls-fpga-machine-learning insert definitions

void myproject_axi(input_axi_t in[N_IN], output_axi_t out[N_OUT]);
#endif
