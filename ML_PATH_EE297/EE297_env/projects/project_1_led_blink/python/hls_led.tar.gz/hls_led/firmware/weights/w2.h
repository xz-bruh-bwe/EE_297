//Numpy array shape [1, 1]
//Min -1.386065483093
//Max -1.386065483093
//Number of zeros 0

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
model_default_t w2[1];
#else
model_default_t w2[1] = {-1.3860654831};
#endif

#endif
